
#define JVERSION	"6b  27-Mar-1998"

#define JCOPYRIGHT	"Copyright (C) 1998, Thomas G. Lane"
