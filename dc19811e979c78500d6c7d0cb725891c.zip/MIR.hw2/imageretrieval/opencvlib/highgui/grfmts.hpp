#ifndef _GRFMTS_H_
#define _GRFMTS_H_

#include "grfmt_base.hpp"
#include "grfmt_bmp.hpp"
#include "grfmt_jpeg.hpp"
#include "grfmt_png.hpp"

#endif/*_GRFMTS_H_*/
